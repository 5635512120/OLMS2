<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope = "row" ></th>
                                    <th>Teacher</th>
                                    <th>Subject</th>
                                    <th>Code</th>
                                </tr>
                            </thead>
                            <?php if(!empty($subjects) and isset($subjects)): ?>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                  
                                        <tbody>
                                            <tr>
                                                <th scope = "row"> <?php echo e($index+1); ?> </th>
                                                <td> <?php echo e($subject->owner->name); ?> </td>
                                                <td> <a  href="<?php echo e(url('subject')); ?>/<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></a> </td>
                                                <td> <?php echo e($subject->code); ?> </td>
                                            </tr>
                                        </tbody>                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <?php if(!empty($subjects) and isset($subjects)): ?>
                    <div class="text-center">
                        <?php echo e($subjects->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>