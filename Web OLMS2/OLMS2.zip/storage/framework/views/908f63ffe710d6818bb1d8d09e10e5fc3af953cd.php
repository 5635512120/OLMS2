<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <div class="panel panel-default">
                    <div class="panel-body">
                    <div class="table-responsive">
                        <form method="post" >
                        <?php echo csrf_field(); ?>

                        <table class="table table-hover">
                            
                            <button class="btn btn-primary btn-xs" type="submit" formaction="<?php echo e(url('deleteall')); ?>" onclick="daleteAll()">Delete check <span class="glyphicon glyphicon-remove"> </span></button> &nbsp;
                            <?php if (Auth::check() && Auth::user()->hasRole('teacher | admin')): ?>
                                <button class="btn btn-primary btn-xs" type="submit" formaction="<?php echo e(url('acceptall')); ?>" onclick="acceptAll()">Accept check <span class="glyphicon glyphicon-ok"> </span></button> &nbsp;
                                <button class="btn btn-primary btn-xs" type="submit" formaction="<?php echo e(url('ejectall')); ?>" onclick="ejectAll()">Eject check <span class="glyphicon glyphicon-ban-circle"> </span></button>
                            <?php endif; ?>
                            <thead>
                                <tr>
                                    <th scope = "row" >
                                        #
                                    </th>
                                    <th>Code</th>
                                    <th class="col-md-1">Subject</th>
                                    <th class="col-md-4">Description</th>
                                    <th class="col-md-1">Date</th>
                                    <th>Status</th>
                                    <th>Option</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($activity) and isset($activity)): ?>
                                <?php $__currentLoopData = $activity->activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $activitys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                  
                                        <tbody>
                                            <tr>
                                                <th scope = "row"> <input type="checkbox" id="<?php echo e($index); ?>" name="chk[]" value="<?php echo e($activitys->id); ?>" > <?php echo e($index+1); ?></th>
                                                <td class="col-md-1"> <a  href="<?php echo e(url('subject')); ?>/<?php echo e($activitys->subject->id); ?>"><?php echo e($activitys->subject->code); ?></a> </td>
                                                <td class="col-md-1">
                                                    <span class="glyphicon glyphicon-paperclip"></span>
                                                    <?php echo e($activitys->subject->name); ?> 
                                                </td>
                                                <td class="col-md-4"> <?php echo e($activitys->description); ?> </td>
                                                <td class="col-md-1"><span class="label label-info"> <?php echo e($activitys->Start); ?> </span></td>
                                                <td>
                                                    <?php if( $activitys->status  == 0): ?>
                                                        <span class="label label-warning">ขอลาครั้งที่ <?php echo e($activitys->count); ?></span><br>
                                                        <span class="label label-warning">รออนุมัติการลา</span>
                                                    <?php elseif( $activitys->status  == 1): ?>
                                                        <span class="label label-warning">ขอลาครั้งที่ <?php echo e($activitys->count); ?></span><br>
                                                        <span class="label label-success">อนุมัติการลา</span>
                                                    <?php else: ?>
                                                        <span class="label label-warning">ขอลาครั้งที่ <?php echo e($activitys->count); ?></span><br>
                                                        <span class="label label-danger">ไม่อนุมัติการลา</span> 
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if (Auth::check() && Auth::user()->hasRole('teacher')): ?>
                                                        <?php if($activitys->status == 0): ?>
                                                            <a onclick="confirmAccept(<?php echo e($activitys->id); ?>)" class="btn btn-primary btn-xs" >อนุมัติการลา <span class="glyphicon glyphicon-ok"> </span></a><br>
                                                            <a onclick="confirmEject(<?php echo e($activitys->id); ?>)" class="btn btn-default btn-xs" >ปฏิเสธการลา <span class="glyphicon glyphicon-ban-circle"> </span></a>
                                                        <?php elseif($activitys->status): ?>
                                                            <!-- <a href="<?php echo e(url('/activity/delete')); ?>/<?php echo e($activitys->id); ?>"><span class="glyphicon glyphicon-cog"></span></a> -->
                                                            <!-- <a  onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">
                                                                <span class="glyphicon glyphicon-remove"></span>
                                                            </a> -->
                                                            <button class="btn btn-danger btn-xs" onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">ลบ <span class="glyphicon glyphicon-remove"> </span></button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>  
                                                    <?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
                                                        <?php if($activitys->status == 0): ?>
                                                            <button class="btn btn-primary btn-xs" onclick="confirmAccept(<?php echo e($activitys->id); ?>)">อนุมัติการลา <span class="glyphicon glyphicon-ok"> </span></button><br>
                                                            <button class="btn btn-default btn-xs" onclick="confirmEject(<?php echo e($activitys->id); ?>)">ปฏิเสธการลา <span class="glyphicon glyphicon-ban-circle"> </span></button>
                                                        <?php elseif($activitys->status): ?>
                                                            <!-- <a href="<?php echo e(url('/activity/delete')); ?>/<?php echo e($activitys->id); ?>"><span class="glyphicon glyphicon-cog"></span></a> -->
                                                            <!-- <a  onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">
                                                                <span class="glyphicon glyphicon-remove"></span>
                                                            </a> -->
                                                            <button class="btn btn-danger btn-xs" onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">ลบ <span class="glyphicon glyphicon-remove"> </span></button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if (Auth::check() && Auth::user()->hasRole('student')): ?>
                                                        <!-- <a href="<?php echo e(url('/activity/edit')); ?>/<?php echo e($activitys->id); ?>"><span class="glyphicon glyphicon-cog"></span></a>
                                                        <a  onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">
                                                            <span class="glyphicon glyphicon-remove"></span>
                                                        </a> -->
                                                        <button class="btn btn-danger btn-xs" onclick="confirmDelete(<?php echo e($activitys->id); ?>)" method="delete">ลบ <span class="glyphicon glyphicon-remove"> </span></button>
                                                    <?php endif; ?> 
                                                </td>
                                            </tr>
                                        </tbody>
                                    </div>                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>