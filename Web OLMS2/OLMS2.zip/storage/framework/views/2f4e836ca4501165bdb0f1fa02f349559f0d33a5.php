<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(isset($success)): ?> 
        <div class="alert alert-success">
	        <ul>
               <?php echo e($success); ?>

	        </ul>
		</div>
    <?php endif; ?> 
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading"><b>Subject</b>
                        <?php if (Auth::check() && Auth::user()->hasRole('student')): ?>
                            
                            <div class="pull-right">
                            <a href="<?php echo e(url('activity/create')); ?>/<?php echo e($subject->id); ?>">
                                <button  class="btn btn-primary btn-sm">
                                    ขอลา
                                </button>
                            </a>&nbsp;
                            
                                <a href="<?php echo e(url('follow')); ?>/<?php echo e($subject->id); ?>">
                                    <?php if(isset($students)): ?>
                                        <button class="btn btn-danger btn-sm">กำลังติดตาม</button>
                                    <?php else: ?>
                                        <button class="btn btn-danger btn-sm">ติดตาม</button>
                                    <?php endif; ?>
                                </a>
                            </div>
                            
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <ul>
                            <li>รายวิชา : <?php echo e($subject->name); ?> </li>
                            <li>รหัสวิชา : <?php echo e($subject->code); ?> </li>
                            <li>อาจารย์ผู้สอน : <?php echo e($subject->owner->name); ?> </li>
                        </ul>
                    </div>
                    
                </div>
                
            </div>
        </div>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('postnews')); ?>/<?php echo e($subject->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POST')); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <div class="col-md-12"><br>
                                <textarea id="name" type="text" class="form-control" name="name" placeholder="ประกาศ..." required autofocus></textarea>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>                        
                            <div>
                                <button type="submit" class="btn btn-primary" href="<?php echo e(url('postnews')); ?>/<?php echo e($subject->id); ?>">
                                    Post
                                </button>
                            </div><br>                       
                    </form>
                <?php endif; ?> 
                <?php if (Auth::check() && Auth::user()->hasRole('teacher')): ?>
                <form class="form-horizontal" method="POST" action="<?php echo e(url('postnews')); ?>/<?php echo e($subject->id); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('POST')); ?>

                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-1 control-label">ประกาศ</label>
                    <div class="col-md-12"><br>
                        <textarea id="name" type="text" class="form-control" name="name" required autofocus></textarea>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>                        
                    <div>
                        <button type="submit" class="btn btn-primary" href="<?php echo e(url('postnews')); ?>/<?php echo e($subject->id); ?>">
                            Post
                        </button>
                    </div>  <br>                     
            </form>
                <?php endif; ?> 
            </div>
        </div>       
    </div>
    <!-- <?php if (Auth::check() && Auth::user()->hasRole('admin'||'teacher')): ?> -->
    
    <!-- <?php endif; ?> -->
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                
                <?php if(!empty($subject) and isset($subject)): ?>
                    <?php $__currentLoopData = $subject->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subjects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-primary">
                        <div class="rows panel-heading">
                            <b><?php echo e($subject->name); ?></b>
                            <?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
                                <div class="pull-right">
                                    <a href="<?php echo e(url('/deletenews')); ?>/<?php echo e($subjects->id); ?>" method="get">
                                        <span class="glyphicon glyphicon-remove" style="color:white;"></span>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if (Auth::check() && Auth::user()->hasRole('teacher')): ?>
                                <div class="pull-right">
                                    <a href="<?php echo e(url('/deletenews')); ?>/<?php echo e($subjects->id); ?>" method="get">
                                        <span class="glyphicon glyphicon-remove" style="color:white;"></span>
                                    </a>
                                </div>
                            <?php endif; ?>  
                        </div>
                        <div class="panel-body">
                            <ul>
                                <p style="word-wrap:break-word;"><?php echo e($subject->owner->name); ?> : <?php echo e($subjects->comment); ?></p> 
                                ใช้งานครั้งล่าสุด : <span class="label label-danger"><?php echo e($subjects->created_at->diffForHumans()); ?></span> <br>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>