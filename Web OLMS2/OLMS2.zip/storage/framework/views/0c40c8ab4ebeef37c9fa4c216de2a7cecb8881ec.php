<?php $__env->startSection('content'); ?>
<h3><?php echo e($user->fromSubject); ?></h3>
    	<p>เรื่อง  <?php echo e($user->fromName); ?></p>  <br>
    	<p>เรียน  <?php echo e($user->toName); ?></p>  <br>
    	<p>	ด้วยข้าพเจ้า <?php echo e($user->fromMessage); ?> มีความประสงค์จะขอ <?php echo e($user->formats); ?> 
			เนื่องจาก <?php echo e($user->description); ?> 
		</p> <br>
		<p>	ดังนั้น ข้าพเจ้าจึงขอลาเป็นจํานวน 1 วัน ตั้งแต่วันที่ <?php echo e($user->Start); ?> 
			ถึงวันที่ <?php echo e($user->Start); ?> เมื่อครบกําหนดแล้ว จะมาเรียนตามปกติ</p><br>
		<p>	จึงเรียนมาเพื่อโปรดพิจารณาอนุญาต</p><br>
		<p>ด้วยความเคารพอย่างสูง</p>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>