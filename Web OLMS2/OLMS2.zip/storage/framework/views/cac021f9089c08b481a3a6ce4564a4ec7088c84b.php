<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        
        <?php if(!empty($subject) and isset($subject)): ?>
        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subjects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <?php if(!empty($subjects) and isset($subjects)): ?>
                <?php $__currentLoopData = $subjects->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-primary">
                        <div class="panel-heading"><b><?php echo e($subjects->name); ?></b></div>
                        <div class="panel-body">
                            <ul>
                                 <P><?php echo e($sub->comment); ?></P> 
                                ประกาศเมื่อ : <span class="label label-danger"><?php echo e($sub->created_at->diffForHumans()); ?></span> <br>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>