<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(isset($success)): ?> 
        <div class="alert alert-success">
	        <ul>
               <?php echo e($success); ?>

	        </ul>
		</div>
    <?php endif; ?> 
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Create Subject</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="/subject">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POST')); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Subject name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                            <label for="code" class="col-md-4 control-label">Code subject</label>

                            <div class="col-md-6">
                                <input id="code" type="text" class="form-control" name="code" required>

                                <?php if($errors->has('code')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" href="subject">
                                    Create
                                </button>

                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>