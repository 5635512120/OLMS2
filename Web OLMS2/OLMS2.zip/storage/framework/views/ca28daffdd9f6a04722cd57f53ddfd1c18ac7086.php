<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="alert alert-info">
                    <strong>อาจารย์ทั้งหมด</strong>
                </div>
                <?php if(!empty($teachers) and isset($teachers)): ?>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel panel-primary">
                            <div class="panel-heading"><b><?php echo e($teacher->name); ?></b></div>
                            <div class="panel-body">
                                <ul>
                                    อีเมล์ : <?php echo e($teacher->email); ?> <br>
                                    เข้าร่วมเมื่อ : <?php echo e($teacher->created_at->format('d M Y')); ?> (<?php echo e($teacher->created_at->diffForHumans()); ?>) <br>
                                    ใช้งานครั้งล่าสุด : <span class="label label-danger"><?php echo e($teacher->updated_at->diffForHumans()); ?></span> <br>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    <div class="text-center">
                        <?php echo e($teachers->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>