<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>OLMS2</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('js/confirm.js')); ?>"></script>
    <!-- Latest compiled and minified CSS -->
    <link href="<?php echo e(asset('css/toggle.min.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('js/toggle.js')); ?>"></script>

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        OLMS2
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">บริหารจัดการ
                                <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('subject.index')); ?>">รายวิชาทั้งหมด</a></li>
                                    <li><a href="<?php echo e(route('user.index')); ?>">ผู้ใช้งานทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.student')); ?>">นักศึกษาทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.teacher')); ?>">อาจารย์ทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.admin')); ?>">ผู้ดูแลทั้งหมด</a></li> 
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('status')); ?>">ขอลา</a></li>
                            <li><a href="<?php echo e(route('subject.create')); ?>">สร้างรายวิชา</a></li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->hasRole('teacher')): ?>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">บริหารจัดการ
                                <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('subject.index')); ?>">รายวิชาทั้งหมด</a></li>
                                    <li><a href="<?php echo e(route('user.index')); ?>">ผู้ใช้งานทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.student')); ?>">นักศึกษาทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.teacher')); ?>">อาจารย์ทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.admin')); ?>">ผู้ดูแลทั้งหมด</a></li> 
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('status')); ?>">ขอลา</a></li>
                            <li><a href="<?php echo e(route('subject.create')); ?>">สร้างรายวิชา</a></li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->hasRole('student')): ?>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">บริหารจัดการ
                                <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('subject.index')); ?>">รายวิชาทั้งหมด</a></li>                                                    
                                    <li><a href="<?php echo e(route('user.teacher')); ?>">อาจารย์ทั้งหมด</a></li> 
                                    <li><a href="<?php echo e(route('user.admin')); ?>">ผู้ดูแลทั้งหมด</a></li>
                                    <li><a href="<?php echo e(route('user.admin')); ?>">รายวิชาติดตาม</a></li> 
                                </ul>
                            </li>                           
                            <li>
                                <a href="<?php echo e(url('activity')); ?>">สถาณะการลา</a>
                            </li>
                            <li >
                                <a id="btnshow"><span onclick="showSearch()" class="glyphicon glyphicon-search"></span></a>
                                <div class="dropdown" id="show" style="display:none;">
                                    <form action="/search" method="get" class="navbar-form">
                                    <?php echo csrf_field(); ?>

                                        <input name="search" type="text" class="form-control "  placeholder="ค้นหารายวิชา" >
                                        <button type="submit" class="btn btn-primary" >ค้นหา <span class="glyphicon glyphicon-search"></span></button>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    Notification 
                                    <?php if(Auth::user()->unreadnotifications->count()): ?>
                                        <span class="badge"><?php echo e(Auth::user()->unreadnotifications->count()); ?></span>
                                    <?php endif; ?>
                                </a>
                                <?php if(Auth::user()->unreadnotifications->count()): ?>
                                    <ul class="dropdown-menu" role="menu">
                                        <li>
                                            <a href="<?php echo e(url('markasRead')); ?>">mark as all read</a>
                                            <?php $__currentLoopData = Auth::user()->unreadnotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->type == 'App\Notifications\NewsNotifications'): ?>
                                                    <a href="<?php echo e(url('subject')); ?>/<?php echo e($data->data['target']); ?>">วิชา <?php echo e($data->data['data']); ?> มีข้อความใหม่</a>
                                                <?php elseif($data->type == 'App\Notifications\InvoicePaid'): ?>
                                                    <a href="<?php echo e(url('activity')); ?>">คำขอลาวิชา <?php echo e($data->data['data']); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    </ul>
                                 <?php endif; ?>
                            </li>                      
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->username); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
